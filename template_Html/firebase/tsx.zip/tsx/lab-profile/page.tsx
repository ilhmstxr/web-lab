
import Image from 'next/image';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Microscope, Dna, FlaskConical, Users, BookOpen, ExternalLink } from 'lucide-react';
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import { cn } from '@/lib/utils';

type MemberProfile = {
  name: string;
  role: string;
  fallback: string;
  googleScholarUrl: string;
  scopusId: string;
  sintaId: string;
};

const lab1Data = {
  name: 'Laboratorium Bioteknologi Molekuler',
  description: 'Fokus pada rekayasa genetika dan pengembangan terapi inovatif. Kami memanfaatkan teknologi CRISPR-Cas9 dan sekuensing generasi berikutnya untuk memahami dan memanipulasi sistem biologis pada tingkat molekuler.',
  head: {
    name: 'Prof. Dr. Adisti Wulandari',
    role: 'Kepala Laboratorium',
    fallback: 'AW',
    googleScholarUrl: 'https://scholar.google.com/citations?user=jBtlq7UAAAAJ',
    scopusId: '57218795432',
    sintaId: '6192423',
  },
  members: [
    { name: 'Dr. Bambang Sugiono', role: 'Peneliti Senior', fallback: 'BS', googleScholarUrl: '#', scopusId: '57218795433', sintaId: '6192424' },
    { name: 'Sari Puspita, M.Sc.', role: 'Peneliti', fallback: 'SP', googleScholarUrl: '#', scopusId: '57218795434', sintaId: '6192425' },
    { name: 'Joko Anwar, S.Si.', role: 'Asisten Peneliti', fallback: 'JA', googleScholarUrl: '#', scopusId: '57218795435', sintaId: '6192426' },
    { name: 'Citra Lestari, S.Si.', role: 'Asisten Peneliti', fallback: 'CL', googleScholarUrl: '#', scopusId: '57218795436', sintaId: '6192427' },
  ],
  researchTopics: [
    'Terapi Gen untuk Penyakit Keturunan',
    'Pengembangan Vaksin DNA',
    'Biologi Sintetis untuk Produksi Biofuel',
    'Analisis Transkriptomik Sel Tunggal',
  ],
  photos: [
    { src: 'https://placehold.co/400x400.png', alt: 'Peralatan lab modern', hint: 'lab equipment' },
    { src: 'https://placehold.co/400x400.png', alt: 'Tim sedang berdiskusi', hint: 'scientists discussion' },
    { src: 'https://placehold.co/400x400.png', alt: 'Sekuenser DNA', hint: 'DNA sequencer' },
    { src: 'https://placehold.co/400x400.png', alt: 'Kultur sel di inkubator', hint: 'cell culture' },
  ],
  publications: [
    'Wulandari, A., et al. (2023). "CRISPR-Cas9-mediated gene correction in hematopoietic stem cells." Nature Biotechnology.',
    'Sugiono, B., et al. (2022). "A novel DNA vaccine platform for emerging infectious diseases." Journal of Virology.',
    'Puspita, S., et al. (2024). "Single-cell RNA-seq reveals cellular heterogeneity in tumor microenvironments." Cell.',
  ],
};

const lab2Data = {
  name: 'Laboratorium Material Maju & Nanoteknologi',
  description: 'Berdedikasi pada sintesis dan karakterisasi material baru dengan sifat unggul untuk aplikasi di bidang energi, lingkungan, dan elektronik. Kami mengeksplorasi material 2D, komposit, dan nanopartikel.',
  head: {
    name: 'Dr. Eng. Rendra Pratama',
    role: 'Kepala Laboratorium',
    fallback: 'RP',
    googleScholarUrl: 'https://scholar.google.com/citations?user=jBtlq7UAAAAJ',
    scopusId: '57218795555',
    sintaId: '6192555',
  },
  members: [
    { name: 'Dr. Indah Cahyani', role: 'Peneliti Senior', fallback: 'IC', googleScholarUrl: '#', scopusId: '57218795556', sintaId: '6192556' },
    { name: 'Gilang Ramadhan, M.Eng.', role: 'Peneliti', fallback: 'GR', googleScholarUrl: '#', scopusId: '57218795557', sintaId: '6192557' },
    { name: 'Putri Ayu, S.T.', role: 'Asisten Peneliti', fallback: 'PA', googleScholarUrl: '#', scopusId: '57218795558', sintaId: '6192558' },
    { name: 'Agung Wicaksono, S.T.', role: 'Asisten Peneliti', fallback: 'AW', googleScholarUrl: '#', scopusId: '57218795559', sintaId: '6192559' },
  ],
  researchTopics: [
    'Sintesis Graphene untuk Superkapasitor',
    'Nanokomposit Polimer untuk Sensor Gas',
    'Fotokatalis TiO2 untuk Degradasi Polutan',
    'Quantum Dots untuk Aplikasi Display',
  ],
  photos: [
    { src: 'https://placehold.co/400x400.png', alt: 'Scanning Electron Microscope', hint: 'electron microscope' },
    { src: 'https://placehold.co/400x400.png', alt: 'Proses sintesis di fume hood', hint: 'fume hood' },
    { src: 'https://placehold.co/400x400.png', alt: 'Karakterisasi material', hint: 'material science' },
    { src: 'https://placehold.co/400x400.png', alt: 'Contoh nanomaterial', hint: 'nanomaterials' },
  ],
  publications: [
    'Pratama, R., et al. (2023). "High-performance supercapacitors based on nitrogen-doped graphene." Advanced Materials.',
    'Cahyani, I., et al. (2022). "A flexible gas sensor using a polymer-nanocomposite film." ACS Nano.',
    'Ramadhan, G., et al. (2024). "Enhanced photocatalytic activity of TiO2 nanostructures for water purification." Applied Catalysis B: Environmental.',
  ],
};

const LabProfilePage = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">
              Profil Laboratorium
            </h1>
            <p className="max-w-[700px] mx-auto text-foreground/80 md:text-xl mt-4">
              Temukan pusat-pusat penelitian unggulan kami, tempat inovasi dan penemuan terjadi.
            </p>
          </div>

          <Tabs defaultValue="lab-1" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="lab-1">Lab Bioteknologi Molekuler</TabsTrigger>
              <TabsTrigger value="lab-2">Lab Material Maju</TabsTrigger>
            </TabsList>
            <TabsContent value="lab-1">
              <LabDetail {...lab1Data} />
            </TabsContent>
            <TabsContent value="lab-2">
              <LabDetail {...lab2Data} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

type LabDetailProps = {
    name: string;
    description: string;
    head: MemberProfile;
    members: MemberProfile[];
    researchTopics: string[];
    photos: { src: string; alt: string; hint: string; }[];
    publications: string[];
}


const LabDetail = ({ name, description, head, members, researchTopics, photos, publications }: LabDetailProps) => (
    <Card className="mt-6 border-0 shadow-none">
        <CardContent className="p-0 space-y-16">
            <section id="lab-info">
                <h2 className="text-3xl font-bold font-headline mb-4">{name}</h2>
                <p className="text-foreground/80 leading-relaxed">{description}</p>
            </section>

            <section id="research">
                <h3 className="text-2xl font-bold font-headline mb-6 flex items-center gap-3"><FlaskConical className="w-7 h-7 text-primary" /> Topik Penelitian</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {researchTopics.map((topic, index) => (
                        <Card key={index} className="bg-card hover:shadow-lg transition-shadow">
                            <CardContent className="p-4 flex items-center gap-4">
                                <div className="p-2 bg-primary/10 rounded-full">
                                    <Dna className="w-6 h-6 text-primary flex-shrink-0" />
                                </div>
                                <p className="text-foreground/90 font-medium">{topic}</p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </section>

            <section id="members">
                <h3 className="text-2xl font-bold font-headline mb-6 flex items-center gap-3"><Users className="w-7 h-7 text-primary" /> Tim Laboratorium</h3>
                <div className="space-y-10">
                    <div>
                        <h4 className="font-semibold text-xl mb-4 text-foreground/80">Kepala Laboratorium</h4>
                        <Card className="max-w-lg">
                            <CardContent className="p-6 flex flex-col sm:flex-row items-start gap-6">
                                <Avatar className="w-24 h-24 border-2 border-primary flex-shrink-0">
                                    <AvatarFallback className="text-3xl">{head.fallback}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <h5 className="font-bold text-xl">{head.name}</h5>
                                    <p className="text-md text-primary font-semibold mb-3">{head.role}</p>
                                    <div className="space-y-1 text-sm text-foreground/80">
                                        <p><strong className="font-medium">ID Scopus:</strong> {head.scopusId}</p>
                                        <p><strong className="font-medium">ID Sinta:</strong> {head.sintaId}</p>
                                        <a href={head.googleScholarUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-medium inline-flex items-center gap-1.5">
                                            Profil Google Scholar <ExternalLink className="w-4 h-4" />
                                        </a>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                     <div>
                        <h4 className="font-semibold text-xl mb-4 text-foreground/80">Anggota Tim</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            {members.map((member, index) => (
                                <Card key={index} className="hover:shadow-lg transition-shadow flex flex-col">
                                    <CardContent className="p-4 flex-1 flex flex-col items-center text-center gap-2">
                                        <Avatar className="w-24 h-24 mb-2">
                                             <AvatarFallback className="text-3xl">{member.fallback}</AvatarFallback>
                                        </Avatar>
                                        <h5 className="font-semibold text-lg">{member.name}</h5>
                                        <p className="text-sm text-foreground/70">{member.role}</p>
                                    </CardContent>
                                    <div className="border-t p-4 text-left text-xs space-y-1.5 text-foreground/80 mt-auto">
                                        <p><strong className="font-medium">Scopus:</strong> {member.scopusId}</p>
                                        <p><strong className="font-medium">Sinta:</strong> {member.sintaId}</p>
                                        <a href={member.googleScholarUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-medium inline-flex items-center gap-1">
                                            Google Scholar <ExternalLink className="w-3 h-3" />
                                        </a>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            <section id="gallery">
                <h3 className="text-2xl font-bold font-headline mb-6 flex items-center gap-3"><Microscope className="w-7 h-7 text-primary" /> Galeri Foto</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {photos.map((photo, index) => (
                        <div key={index} className="overflow-hidden rounded-lg shadow-md">
                            <Image
                                src={photo.src}
                                alt={photo.alt}
                                width={400}
                                height={400}
                                className="object-cover aspect-square hover:scale-105 transition-transform duration-300"
                                data-ai-hint={photo.hint}
                            />
                        </div>
                    ))}
                </div>
            </section>

             <section id="publications">
                <h3 className="text-2xl font-bold font-headline mb-6 flex items-center gap-3"><BookOpen className="w-7 h-7 text-primary" /> Profil Publikasi</h3>
                <Card className="bg-card">
                     <CardContent className="p-6">
                        <ul className="space-y-4 list-disc list-inside text-foreground/80">
                           {publications.map((pub, index) => (
                                <li key={index} className="pl-2">{pub}</li>
                            ))}
                        </ul>
                    </CardContent>
                </Card>
            </section>
        </CardContent>
    </Card>
);

export default LabProfilePage;
