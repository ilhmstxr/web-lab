
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen } from 'lucide-react';

export default function PanduanPkmPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">
              Panduan Program Kreativitas Mahasiswa (PKM)
            </h1>
            <p className="max-w-[800px] mx-auto text-foreground/80 md:text-xl mt-4">
              Informasi lengkap dan panduan untuk mengikuti PKM.
            </p>
          </div>
          <Card className="max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-primary" />
                <span>Konten Segera Hadir</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground/80">
                Halaman ini sedang dalam pengembangan. Informasi detail mengenai panduan PKM akan segera tersedia di sini. Terima kasih atas kesabaran Anda.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
