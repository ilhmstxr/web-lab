'use client';

import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Calendar as CalendarIcon, Microscope, Dna, FlaskConical, QrCode, HardDrive, TestTube, Wind } from 'lucide-react';

import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';

const bookingFormSchema = z.object({
  name: z.string().min(3, { message: 'Nama harus diisi, minimal 3 karakter.' }),
  institution: z.string().min(3, { message: 'Institusi/Prodi harus diisi.' }),
  lab: z.enum(['biotek', 'material'], { required_error: 'Silakan pilih laboratorium.' }),
  date: z.date({ required_error: 'Tanggal pemesanan harus diisi.' }),
  session: z.enum(['pagi', 'siang'], { required_error: 'Silakan pilih sesi waktu.' }),
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

const facilities = [
    { name: 'Scanning Electron Microscope (SEM)', description: 'Untuk analisis morfologi permukaan dengan resolusi tinggi.', icon: Microscope, lab: 'material' },
    { name: 'PCR Machine', description: 'Untuk amplifikasi sekuens DNA secara in vitro.', icon: Dna, lab: 'biotek' },
    { name: 'Fume Hood', description: 'Lemari asam untuk bekerja dengan bahan kimia berbahaya secara aman.', icon: Wind, lab: 'material' },
    { name: 'Cell Culture Incubator', description: 'Menyediakan lingkungan terkontrol untuk pertumbuhan kultur sel.', icon: TestTube, lab: 'biotek' },
    { name: 'High-Performance Computing', description: 'Server untuk komputasi dan analisis data yang kompleks.', icon: HardDrive, lab: 'both' },
    { name: 'UV-Vis Spectrophotometer', description: 'Mengukur absorbansi cahaya oleh sampel larutan.', icon: FlaskConical, lab: 'both' },
];

const scheduleData = [
    { day: 'Senin', morning: { lab: 'Bioteknologi', status: 'Dipesan' }, afternoon: { lab: 'Material Maju', status: 'Tersedia' } },
    { day: 'Selasa', morning: { lab: 'Material Maju', status: 'Dipesan' }, afternoon: { lab: 'Material Maju', status: 'Dipesan' } },
    { day: 'Rabu', morning: { lab: 'Bioteknologi', status: 'Tersedia' }, afternoon: { lab: 'Bioteknologi', status: 'Dipesan' } },
    { day: 'Kamis', morning: { lab: 'Material Maju', status: 'Tersedia' }, afternoon: { lab: 'Bioteknologi', status: 'Tersedia' } },
    { day: 'Jumat', morning: { lab: 'Bioteknologi', status: 'Dipesan' }, afternoon: { lab: 'Material Maju', status: 'Tersedia' } },
];


const BookingForm = () => {
  const { toast } = useToast();
  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      name: '',
      institution: '',
    },
  });

  function onSubmit(data: BookingFormValues) {
    console.log(data);
    toast({
      title: "Pemesanan Berhasil!",
      description: `Lab telah dipesan oleh ${data.name} untuk tanggal ${format(data.date, 'PPP', { locale: id })}.`,
    });
    form.reset();
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Formulir Pemesanan Online</CardTitle>
        <CardDescription>Isi formulir di bawah ini untuk melakukan pemesanan jadwal penggunaan lab.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nama Lengkap</FormLabel>
                  <FormControl>
                    <Input placeholder="Contoh: Budi Santoso" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="institution"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Institusi / Program Studi</FormLabel>
                  <FormControl>
                    <Input placeholder="Contoh: Universitas Teknologi Persada" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <FormField
                  control={form.control}
                  name="lab"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Laboratorium</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih laboratorium" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="biotek">Lab Bioteknologi Molekuler</SelectItem>
                          <SelectItem value="material">Lab Material Maju</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Tanggal Penggunaan</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP", { locale: id })
                              ) : (
                                <span>Pilih tanggal</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date() || date.getDay() === 0 || date.getDay() === 6}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
            </div>
             <FormField
                  control={form.control}
                  name="session"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sesi Waktu</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Pilih sesi waktu" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="pagi">Pagi (08:00 - 12:00)</SelectItem>
                          <SelectItem value="siang">Siang (13:00 - 17:00)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
            <Button type="submit" className="w-full">Kirim Permintaan</Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};


const ScheduleTable = () => (
    <Card>
        <CardHeader>
            <CardTitle>Jadwal Penggunaan Laboratorium</CardTitle>
            <CardDescription>Jadwal penggunaan harian untuk laboratorium di hari kerja.</CardDescription>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Hari</TableHead>
                        <TableHead>Sesi Pagi (08:00 - 12:00)</TableHead>
                        <TableHead>Sesi Siang (13:00 - 17:00)</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {scheduleData.map(item => (
                         <TableRow key={item.day}>
                            <TableCell className="font-medium">{item.day}</TableCell>
                            <TableCell>
                                <div className={cn(
                                    'p-2 rounded-md text-center text-sm font-medium',
                                    item.morning.status === 'Dipesan' ? 'bg-destructive/10 text-destructive' : 'bg-accent/10 text-accent'
                                )}>
                                    {item.morning.lab} <br/> ({item.morning.status})
                                </div>
                            </TableCell>
                            <TableCell>
                                 <div className={cn(
                                    'p-2 rounded-md text-center text-sm font-medium',
                                    item.afternoon.status === 'Dipesan' ? 'bg-destructive/10 text-destructive' : 'bg-accent/10 text-accent'
                                )}>
                                    {item.afternoon.lab} <br/> ({item.afternoon.status})
                                </div>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </CardContent>
    </Card>
);

const FacilityDetails = () => (
     <Card>
        <CardHeader>
            <CardTitle>Fasilitas Laboratorium</CardTitle>
            <CardDescription>Berikut adalah beberapa fasilitas dan peralatan utama yang tersedia di laboratorium kami.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {facilities.map((facility, index) => {
               const Icon = facility.icon;
               return (
                <Card key={index} className="flex flex-col">
                    <CardHeader className="flex flex-row items-center gap-4 pb-4">
                        <div className="p-3 bg-primary/10 rounded-full">
                            <Icon className="w-8 h-8 text-primary" />
                        </div>
                        <CardTitle className="text-lg">{facility.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="flex-1">
                        <p className="text-foreground/80">{facility.description}</p>
                    </CardContent>
                    <CardFooter>
                         <span className="text-xs text-foreground/60">Tersedia di: {facility.lab === 'biotek' ? 'Lab Biotek' : facility.lab === 'material' ? 'Lab Material' : 'Kedua Lab'}</span>
                    </CardFooter>
                </Card>
               )
           })}
        </CardContent>
    </Card>
);

const AttendanceInfo = () => (
    <Card className="bg-primary/5 border-primary/20">
         <CardHeader className="flex-row gap-4 items-center">
            <QrCode className="w-10 h-10 text-primary flex-shrink-0" />
            <div>
                <CardTitle>Absensi Kehadiran</CardTitle>
                <CardDescription>Informasi mengenai sistem pencatatan kehadiran di lab.</CardDescription>
            </div>
        </CardHeader>
        <CardContent>
            <p className="text-foreground/80">
                Setiap pengguna lab diwajibkan untuk melakukan absensi dengan memindai kode QR yang tersedia di pintu masuk laboratorium. 
                Pencatatan kehadiran ini penting untuk tujuan keamanan dan administrasi. Pastikan Anda melakukan scan saat masuk dan keluar lab.
            </p>
        </CardContent>
    </Card>
);


export default function LabBookingPage() {
    return (
        <div className="flex flex-col min-h-screen bg-background">
            <Header />
            <main className="flex-1 py-12 md:py-24 lg:py-32">
                <div className="container mx-auto px-4 md:px-6">
                    <div className="text-center mb-12">
                        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">
                            Manajemen Laboratorium
                        </h1>
                        <p className="max-w-[800px] mx-auto text-foreground/80 md:text-xl mt-4">
                            Pesan jadwal penggunaan lab, lihat fasilitas yang tersedia, dan kelola kehadiran Anda dengan mudah.
                        </p>
                    </div>

                    <Tabs defaultValue="booking" className="w-full">
                        <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="booking">Pemesanan & Jadwal</TabsTrigger>
                            <TabsTrigger value="facilities">Fasilitas & Informasi</TabsTrigger>
                        </TabsList>
                        <TabsContent value="booking" className="mt-8">
                             <div className="grid lg:grid-cols-2 gap-12">
                                <div>
                                    <BookingForm />
                                </div>
                                <div className="space-y-8">
                                    <ScheduleTable />
                                </div>
                            </div>
                        </TabsContent>
                        <TabsContent value="facilities" className="mt-8 space-y-8">
                           <FacilityDetails />
                           <AttendanceInfo />
                        </TabsContent>
                    </Tabs>

                </div>
            </main>
            <Footer />
        </div>
    );
}
