
'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dna, FlaskConical, Zap, Calendar, DollarSign, Building, CheckCircle2, User, FileText, Info } from 'lucide-react';

import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import { cn } from '@/lib/utils';

const researchData = [
  {
    category: 'Bioteknologi',
    icon: Dna,
    researches: [
      {
        id: 'bio-1',
        title: 'Terapi Gen untuk Penyakit Keturunan',
        lead: 'Prof. Dr. Adisti Wulandari',
        summary: 'Penelitian ini berfokus pada penggunaan teknologi CRISPR-Cas9 untuk memperbaiki mutasi genetik yang menyebabkan penyakit keturunan seperti talasemia dan fibrosis kistik. Kami mengeksplorasi vektor pengiriman yang efisien dan aman untuk sel target.',
        status: 'Berjalan',
        year: 2023,
        collaborators: ['Universitas Gadjah Mada', 'Eijkman Institute'],
        funding: 'Kemenristekdikti',
      },
      {
        id: 'bio-2',
        title: 'Pengembangan Vaksin DNA Generasi Baru',
        lead: 'Dr. Bambang Sugiono',
        summary: 'Riset ini bertujuan mengembangkan platform vaksin DNA yang stabil, mudah diproduksi, dan efektif melawan penyakit menular baru. Fokus saat ini adalah pada virus influenza dan dengue.',
        status: 'Berjalan',
        year: 2024,
        collaborators: ['Bio Farma'],
        funding: 'LPDP',
      },
      {
        id: 'bio-3',
        title: 'Biologi Sintetis untuk Produksi Biofuel',
        lead: 'Sari Puspita, M.Sc.',
        summary: 'Memanfaatkan rekayasa genetika pada mikroalga untuk meningkatkan produksi lipid sebagai bahan baku biofuel. Penelitian ini mencari jalur metabolik yang paling efisien dan tahan terhadap kondisi lingkungan.',
        status: 'Selesai',
        year: 2022,
        collaborators: ['Pertamina Research Center'],
        funding: 'Internal',
      },
    ],
  },
  {
    category: 'Material Maju',
    icon: FlaskConical,
    researches: [
      {
        id: 'mat-1',
        title: 'Sintesis Graphene untuk Superkapasitor',
        lead: 'Dr. Eng. Rendra Pratama',
        summary: 'Mengembangkan metode sintesis graphene berkualitas tinggi dengan biaya rendah untuk aplikasi penyimpanan energi, khususnya pada superkapasitor generasi berikutnya. Tujuannya adalah mencapai kepadatan energi yang tinggi.',
        status: 'Berjalan',
        year: 2023,
        collaborators: ['Institut Teknologi Bandung', 'LIPI'],
        funding: 'LPDP',
      },
      {
        id: 'mat-2',
        title: 'Nanokomposit Polimer untuk Sensor Gas',
        lead: 'Dr. Indah Cahyani',
        summary: 'Membuat material komposit berbasis polimer dan nanopartikel logam oksida yang memiliki sensitivitas dan selektivitas tinggi untuk mendeteksi gas berbahaya seperti CO dan NOx di lingkungan.',
        status: 'Selesai',
        year: 2023,
        collaborators: ['Pusat Penelitian Elektronika dan Telekomunikasi (PPET) LIPI'],
        funding: 'Riset Unggulan',
      },
       {
        id: 'mat-3',
        title: 'Fotokatalis TiO2 untuk Degradasi Polutan',
        lead: 'Gilang Ramadhan, M.Eng.',
        summary: 'Meneliti modifikasi permukaan Titanium Dioksida (TiO2) untuk meningkatkan aktivitas fotokatalitiknya di bawah sinar tampak. Aplikasi utama adalah untuk mendegradasi polutan organik di air limbah industri.',
        status: 'Selesai',
        year: 2021,
        collaborators: [],
        funding: 'Hibah Internal',
      },
    ],
  },
   {
    category: 'Kecerdasan Buatan',
    icon: Zap,
    researches: [
        {
            id: 'ai-1',
            title: 'Model Prediksi Penyakit Berbasis AI',
            lead: 'Dr. Agus Purnomo',
            summary: 'Mengembangkan model machine learning untuk memprediksi risiko penyakit jantung koroner berdasarkan data rekam medis elektronik. Model ini menggunakan arsitektur deep learning untuk akurasi yang lebih tinggi.',
            status: 'Berjalan',
            year: 2024,
            collaborators: ['RS Jantung Harapan Kita'],
            funding: 'Kemenristekdikti'
        }
    ]
   }
];

type Research = (typeof researchData)[0]['researches'][0];

const ResearchDetailCard = ({ research }: { research: Research | null }) => {
    if (!research) {
        return (
            <Card className="sticky top-24 flex items-center justify-center h-96">
                <CardContent className="pt-6">
                    <p className="text-muted-foreground">Pilih riset untuk melihat detail.</p>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="sticky top-24">
            <CardHeader>
                <div className="flex justify-between items-start gap-4">
                    <CardTitle className="text-2xl lg:text-3xl font-headline">{research.title}</CardTitle>
                    <Badge variant="outline" className={cn(
                        'w-fit shrink-0 border-none whitespace-nowrap',
                        research.status === 'Selesai' ? 'bg-accent text-accent-foreground' : 'bg-secondary text-secondary-foreground'
                    )}>
                        {research.status === 'Selesai' ? <CheckCircle2 className="mr-2 h-4 w-4" /> : <Zap className="mr-2 h-4 w-4" />}
                        {research.status}
                    </Badge>
                </div>
                 <CardDescription className="text-md pt-2 flex items-center gap-2">
                    <User className="w-4 h-4" /> 
                    <span>Pimpinan Riset: {research.lead}</span>
                </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
                <div className="border-t pt-6">
                    <h4 className="font-semibold mb-3 text-lg flex items-center gap-2.5"><FileText className="w-5 h-5 text-primary" />Ringkasan Proyek</h4>
                    <p className="text-foreground/80 leading-relaxed pl-8">{research.summary}</p>
                </div>
                
                <div className="border-t pt-6">
                     <h4 className="font-semibold mb-4 text-lg flex items-center gap-2.5"><Info className="w-5 h-5 text-primary" />Detail Informasi</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-y-6 gap-x-4 pl-8">
                        <div className="flex items-center gap-3">
                            <Calendar className="w-6 h-6 text-primary/80" />
                            <div>
                                <p className="text-sm text-foreground/70">Tahun</p>
                                <p className="font-semibold">{research.year}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-3">
                            <DollarSign className="w-6 h-6 text-primary/80" />
                            <div>
                                <p className="text-sm text-foreground/70">Sumber Pendanaan</p>
                                <p className="font-semibold">{research.funding}</p>
                            </div>
                        </div>
                         {research.collaborators && research.collaborators.length > 0 && (
                             <div className="flex items-start gap-3 md:col-span-2">
                                <Building className="w-6 h-6 text-primary/80 flex-shrink-0" />
                                <div>
                                    <p className="text-sm text-foreground/70">Kolaborator</p>
                                    <div className="flex flex-wrap gap-2 mt-1">
                                    {research.collaborators.map(collab => (
                                        <Badge key={collab} variant="secondary">{collab}</Badge>
                                    ))}
                                    </div>
                                </div>
                            </div>
                         )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};


export default function ResearchDetailPage() {
  const [selectedCategory, setSelectedCategory] = useState(researchData[0]);
  const [selectedResearch, setSelectedResearch] = useState<Research | null>(researchData[0].researches[0]);

  const handleSelectCategory = (category: (typeof researchData)[0]) => {
    setSelectedCategory(category);
    setSelectedResearch(category.researches[0]);
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 py-12 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">
              Eksplorasi Riset Unggulan
            </h1>
            <p className="max-w-[800px] mx-auto text-foreground/80 md:text-xl mt-4">
              Selami lebih dalam inovasi dan penemuan yang membentuk masa depan melalui proyek penelitian kami.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
            <div className="lg:col-span-4 xl:col-span-3 space-y-8">
                <Card>
                    <CardHeader>
                        <CardTitle>Kategori Riset</CardTitle>
                    </CardHeader>
                    <CardContent className="flex flex-col gap-2">
                        {researchData.map(cat => {
                            const Icon = cat.icon;
                            return (
                                <Button
                                key={cat.category}
                                variant={selectedCategory.category === cat.category ? "default" : "ghost"}
                                className="justify-start gap-3"
                                onClick={() => handleSelectCategory(cat)}
                                >
                                    <Icon className="w-5 h-5" />
                                    <span>{cat.category}</span>
                                </Button>
                            )
                        })}
                    </CardContent>
                </Card>

                 <Card>
                    <CardHeader>
                        <CardTitle>Daftar Riset</CardTitle>
                        <CardDescription>{selectedCategory.category}</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col gap-3">
                         {selectedCategory.researches.map(res => (
                            <button
                                key={res.id}
                                onClick={() => setSelectedResearch(res)}
                                className={cn(
                                    "p-3 rounded-lg text-left transition-colors text-sm w-full",
                                    selectedResearch?.id === res.id ? 'bg-primary/10 text-primary font-semibold' : 'hover:bg-muted'
                                )}
                            >
                                {res.title}
                            </button>
                        ))}
                    </CardContent>
                </Card>
            </div>

            <div className="lg:col-span-8 xl:col-span-9">
              <ResearchDetailCard research={selectedResearch} />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};
