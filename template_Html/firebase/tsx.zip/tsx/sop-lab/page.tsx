
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { FileText, Shield, FlaskConical, AlertTriangle, BookOpen } from 'lucide-react';

const sopData = [
  {
    value: 'item-1',
    title: 'Prosedur Keselamatan Umum',
    icon: Shield,
    content: [
      'Selalu kenakan jas laboratorium, kacamata pengaman, dan sepatu tertutup di dalam area lab.',
      'Dilarang makan, minum, atau merokok di dalam laboratorium.',
      'Ketahui lokasi alat pemadam api, shower keselamatan, dan kotak P3K.',
      'Laporkan setiap insiden atau tumpahan bahan kimia kepada penanggung jawab lab segera.',
    ],
  },
  {
    value: 'item-2',
    title: 'Penanganan Bahan Kimia',
    icon: FlaskConical,
    content: [
      'Baca Label Keamanan (MSDS/SDS) sebelum menggunakan bahan kimia baru.',
      'Gunakan lemari asam (fume hood) saat bekerja dengan bahan kimia yang mudah menguap atau beracun.',
      'Jangan pernah mencampur bahan kimia secara sembarangan.',
      'Buang limbah kimia pada wadah yang telah ditentukan sesuai jenisnya.',
    ],
  },
  {
    value: 'item-3',
    title: 'Penggunaan Peralatan',
    icon: BookOpen,
    content: [
      'Pastikan Anda telah menerima pelatihan sebelum mengoperasikan peralatan lab.',
      'Periksa kondisi peralatan sebelum digunakan. Laporkan jika ada kerusakan.',
      'Matikan peralatan setelah selesai digunakan dan bersihkan area kerja Anda.',
      'Isi buku log penggunaan untuk peralatan-peralatan utama.',
    ],
  },
    {
    value: 'item-4',
    title: 'Keadaan Darurat',
    icon: AlertTriangle,
    content: [
      'Saat alarm kebakaran berbunyi, matikan semua peralatan dan segera evakuasi melalui jalur evakuasi.',
      'Jika terjadi kontak dengan bahan kimia berbahaya, segera gunakan shower keselamatan selama minimal 15 menit.',
      'Jika terjadi luka, segera berikan pertolongan pertama dan laporkan insiden.',
    ],
  },
];

export default function SopLabPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">
              Standar Operasional Prosedur (SOP)
            </h1>
            <p className="max-w-[800px] mx-auto text-foreground/80 md:text-xl mt-4">
              Panduan penting untuk memastikan keselamatan, efisiensi, dan integritas penelitian di laboratorium kami.
            </p>
          </div>

          <Card>
            <CardHeader>
                <div className="flex items-center gap-4">
                    <FileText className="w-8 h-8 text-primary" />
                    <div>
                        <CardTitle>Dokumen SOP Laboratorium</CardTitle>
                        <CardDescription>
                            Setiap pengguna laboratorium wajib memahami dan mematuhi SOP yang berlaku.
                        </CardDescription>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <Accordion type="single" collapsible className="w-full">
                    {sopData.map((item) => {
                        const Icon = item.icon;
                        return (
                            <AccordionItem value={item.value} key={item.value}>
                                <AccordionTrigger className="text-lg hover:no-underline">
                                    <div className="flex items-center gap-3">
                                        <Icon className="w-6 h-6 text-primary/80" />
                                        <span>{item.title}</span>
                                    </div>
                                </AccordionTrigger>
                                <AccordionContent>
                                    <ul className="list-disc space-y-2 pl-10 text-foreground/80">
                                        {item.content.map((point, index) => (
                                            <li key={index}>{point}</li>
                                        ))}
                                    </ul>
                                </AccordionContent>
                            </AccordionItem>
                        )
                    })}
                </Accordion>
            </CardContent>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
