import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import HeroSection from '@/components/sections/hero-section';
import AboutProgramSection from '@/components/sections/about-program-section';
import LabDetailsSection from '@/components/sections/lab-details-section';
import StudentOrgSection from '@/components/sections/student-org-section';

export default function Home() {
  return (
    <>
      <Header />
      <main className="flex-1">
        <HeroSection />
        <AboutProgramSection />
        <LabDetailsSection />
        <StudentOrgSection />
      </main>
      <Footer />
    </>
  );
}
