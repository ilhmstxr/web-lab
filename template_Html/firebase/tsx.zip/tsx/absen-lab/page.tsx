
import Header from '@/components/layout/header';
import Footer from '@/components/layout/footer';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { QrCode, LogIn, LogOut, Info } from 'lucide-react';

export default function AbsenLabPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <Header />
      <main className="flex-1 py-12 md:py-24 lg:py-32">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl text-primary font-headline">
              Absensi Kehadiran Laboratorium
            </h1>
            <p className="max-w-[800px] mx-auto text-foreground/80 md:text-xl mt-4">
              Sistem pencatatan kehadiran digital untuk keamanan dan administrasi.
            </p>
          </div>

          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8 items-center">
            <Card className="flex flex-col items-center justify-center text-center p-8">
                <CardHeader>
                    <div className="p-4 bg-primary/10 rounded-full mx-auto">
                        <QrCode className="w-16 h-16 text-primary" />
                    </div>
                    <CardTitle className="mt-4 text-2xl">Pindai Kode QR</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-foreground/80">
                        Gunakan kamera ponsel Anda untuk memindai kode QR yang tersedia di pintu masuk dan keluar laboratorium untuk mencatat kehadiran Anda.
                    </p>
                </CardContent>
                <CardFooter>
                     <Button>Buka Pemindai (Contoh)</Button>
                </CardFooter>
            </Card>

            <div className="space-y-6">
                <Card>
                    <CardHeader className="flex-row gap-4 items-center">
                        <LogIn className="w-8 h-8 text-accent flex-shrink-0" />
                        <div>
                             <CardTitle>Prosedur Masuk</CardTitle>
                             <CardDescription>Langkah-langkah saat memasuki lab.</CardDescription>
                        </div>
                    </CardHeader>
                     <CardContent>
                        <p className="text-foreground/80">
                            Sebelum memulai aktivitas, pastikan Anda memindai kode QR 'MASUK' untuk mencatat waktu kedatangan Anda.
                        </p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader className="flex-row gap-4 items-center">
                         <LogOut className="w-8 h-8 text-destructive flex-shrink-0" />
                        <div>
                             <CardTitle>Prosedur Keluar</CardTitle>
                             <CardDescription>Langkah-langkah saat meninggalkan lab.</CardDescription>
                        </div>
                    </CardHeader>
                     <CardContent>
                        <p className="text-foreground/80">
                           Setelah selesai, jangan lupa untuk memindai kode QR 'KELUAR' untuk mencatat waktu kepulangan Anda.
                        </p>
                    </CardContent>
                </Card>
                 <Card className="bg-primary/5 border-primary/20">
                    <CardHeader className="flex-row gap-4 items-center">
                         <Info className="w-8 h-8 text-primary flex-shrink-0" />
                        <div>
                             <CardTitle>Mengapa Absensi Penting?</CardTitle>
                        </div>
                    </CardHeader>
                     <CardContent>
                        <p className="text-foreground/80">
                           Pencatatan kehadiran yang akurat sangat penting untuk rekam jejak keamanan, pemantauan penggunaan fasilitas, dan keperluan administrasi laboratorium.
                        </p>
                    </CardContent>
                </Card>
            </div>
          </div>

        </div>
      </main>
      <Footer />
    </div>
  );
}
