import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Users, Lightbulb } from 'lucide-react';

export default function StudentOrgSection() {
  return (
    <section id="students" className="w-full py-20 lg:py-32 bg-card">
      <div className="container mx-auto px-4 md:px-6 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl font-headline">Gerakan Mahasiswa</h2>
          <p className="mx-auto max-w-[700px] text-foreground/80 md:text-xl">
            Wadah bagi mahasiswa untuk berkreasi, berkolaborasi, dan mengembangkan diri di luar kelas.
          </p>
        </div>
        <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-4">
                <h3 className="text-2xl font-bold font-headline">Komunitas Saintis Muda</h3>
                <p className="text-foreground/80">
                    Komunitas Saintis Muda (KSM) adalah organisasi mahasiswa di bawah naungan LabConnect yang berfokus pada pengembangan minat dan bakat di bidang sains dan teknologi. Kami menyelenggarakan berbagai kegiatan untuk meningkatkan soft skill dan hard skill anggota.
                </p>
                <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                    <Users className="mr-2 h-4 w-4" /> Gabung Sekarang
                </Button>
            </div>
            <div>
                <Image 
                    src="https://placehold.co/600x400.png"
                    alt="Student Activities"
                    width={600}
                    height={400}
                    className="rounded-lg shadow-lg"
                    data-ai-hint="students collaborating"
                />
            </div>
        </div>
        
        <div>
            <h3 className="text-2xl font-bold mb-6 text-center font-headline">Kegiatan Kami</h3>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                    <CardContent className="p-6 text-center space-y-3">
                        <div className="inline-block p-3 bg-primary/10 rounded-full">
                            <Calendar className="w-8 h-8 text-primary" />
                        </div>
                        <h4 className="text-lg font-semibold">Seminar Mingguan</h4>
                        <p className="text-foreground/80 text-sm">Diskusi santai mengenai topik-topik riset terkini bersama dosen dan praktisi.</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardContent className="p-6 text-center space-y-3">
                        <div className="inline-block p-3 bg-primary/10 rounded-full">
                            <Lightbulb className="w-8 h-8 text-primary" />
                        </div>
                        <h4 className="text-lg font-semibold">Workshop Keterampilan</h4>
                        <p className="text-foreground/80 text-sm">Pelatihan praktis penggunaan software, alat lab, dan teknik penulisan ilmiah.</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardContent className="p-6 text-center space-y-3">
                        <div className="inline-block p-3 bg-primary/10 rounded-full">
                            <Users className="w-8 h-8 text-primary" />
                        </div>
                        <h4 className="text-lg font-semibold">Pengabdian Masyarakat</h4>
                        <p className="text-foreground/80 text-sm">Menerapkan ilmu pengetahuan untuk membantu memecahkan masalah di masyarakat.</p>
                    </CardContent>
                </Card>
            </div>
        </div>
      </div>
    </section>
  );
}
