import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { BookOpen, Users, Microscope, GraduationCap, Building, FlaskConical, Dna } from 'lucide-react';

const faculty = [
    { name: 'Dr. Budi Hartono', role: 'Kepala Program Studi' },
    { name: 'Prof. Dr. Siti Aminah', role: 'Guru Besar' },
    { name: 'Dr. Agus Purnomo', role: 'Dosen Peneliti' },
];

const researchAreas = [
    { name: 'Bioteknologi', icon: Dna },
    { name: 'Ilmu Material', icon: Building },
    { name: 'Kecerdasan Buatan', icon: Microscope },
    { name: 'Energi Terbarukan', icon: FlaskConical },
];

export default function AboutProgramSection() {
  return (
    <section id="about" className="w-full py-20 lg:py-32 bg-card">
      <div className="container mx-auto px-4 md:px-6 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl font-headline">Tentang Program Studi</h2>
          <p className="mx-auto max-w-[700px] text-foreground/80 md:text-xl">
            Pelajari lebih lanjut tentang program studi, kurikulum, dan peluang riset yang kami tawarkan.
          </p>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <BookOpen className="w-8 h-8 text-primary" />
              <CardTitle>Kurikulum Unggulan</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground/80">
                Kurikulum kami dirancang untuk membekali mahasiswa dengan pengetahuan teoritis dan keterampilan praktis yang relevan dengan industri.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <Users className="w-8 h-8 text-primary" />
              <CardTitle>Staf Pengajar Ahli</CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2 text-foreground/80">
                    {faculty.map(f => <li key={f.name}>{f.name} - <span className="text-sm">{f.role}</span></li>)}
                </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center gap-4">
              <GraduationCap className="w-8 h-8 text-primary" />
              <CardTitle>Peluang Karir</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground/80">
                Lulusan kami memiliki prospek karir yang cerah di berbagai sektor, dari riset hingga industri teknologi tinggi.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid gap-8 md:grid-cols-2 items-start">
            <div>
                <h3 className="text-2xl font-bold mb-4 font-headline">Area Riset Utama</h3>
                <div className="space-y-4">
                    {researchAreas.map(area => {
                        const Icon = area.icon;
                        return (
                            <div key={area.name} className="flex items-center gap-4">
                                <div className="p-2 bg-primary/10 rounded-full">
                                    <Icon className="w-6 h-6 text-primary" />
                                </div>
                                <span className="font-medium">{area.name}</span>
                            </div>
                        )
                    })}
                </div>
            </div>
            <div>
                <h3 className="text-2xl font-bold mb-4 font-headline">Pertanyaan Umum (FAQ)</h3>
                <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="item-1">
                        <AccordionTrigger>Bagaimana cara mendaftar?</AccordionTrigger>
                        <AccordionContent>
                        Pendaftaran dapat dilakukan secara online melalui portal penerimaan mahasiswa baru universitas kami.
                        </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-2">
                        <AccordionTrigger>Apa saja persyaratan masuk?</AccordionTrigger>
                        <AccordionContent>
                        Persyaratan umum meliputi ijazah SMA/sederajat, nilai rapor, dan lulus ujian saringan masuk. Detail lengkap tersedia di situs web kami.
                        </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="item-3">
                        <AccordionTrigger>Apakah ada program beasiswa?</AccordionTrigger>
                        <AccordionContent>
                        Ya, kami menyediakan berbagai program beasiswa untuk mahasiswa berprestasi dan yang membutuhkan dukungan finansial.
                        </AccordionContent>
                    </AccordionItem>
                </Accordion>
            </div>
        </div>

      </div>
    </section>
  );
}
