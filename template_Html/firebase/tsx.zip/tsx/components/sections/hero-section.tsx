import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Rocket, Target, Users } from 'lucide-react';

export default function HeroSection() {
  return (
    <section id="home" className="w-full py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-4">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl text-primary font-headline">
              Selamat Datang di LabConnect
            </h1>
            <p className="max-w-[600px] text-foreground/80 md:text-xl">
              Pusat inovasi dan penelitian terdepan. Kami mendedikasikan diri untuk memajukan ilmu pengetahuan dan teknologi melalui kolaborasi dan penemuan.
            </p>
            <Button size="lg" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
              <a href="#about">Jelajahi Lebih Lanjut</a>
            </Button>
          </div>
          <div className="grid gap-6 md:grid-cols-1">
             <Card>
              <CardHeader className="flex flex-row items-center gap-4">
                <Target className="w-8 h-8 text-primary" />
                <CardTitle className="font-headline">Misi Kami</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80">
                  Mendorong batas-batas pengetahuan melalui penelitian inovatif dan pendidikan berkualitas tinggi.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center gap-4">
                <Rocket className="w-8 h-8 text-primary" />
                <CardTitle className="font-headline">Visi Kami</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground/80">
                  Menjadi laboratorium riset yang diakui secara global, yang memberikan dampak signifikan bagi masyarakat dan industri.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
