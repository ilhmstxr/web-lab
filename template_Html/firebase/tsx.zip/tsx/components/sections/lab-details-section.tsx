import Image from 'next/image';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Microscope, Beaker, Dna } from 'lucide-react';

const facilities = [
  {
    name: 'Laboratorium Mikrobiologi',
    description: 'Dilengkapi dengan mikroskop canggih dan peralatan kultur sel.',
    image: 'https://placehold.co/600x400.png',
    hint: 'microscope laboratory',
  },
  {
    name: 'Laboratorium Kimia Analitik',
    description: 'Peralatan spektroskopi dan kromatografi untuk analisis presisi.',
    image: 'https://placehold.co/600x400.png',
    hint: 'chemistry lab',
  },
  {
    name: 'Ruang Komputasi Kinerja Tinggi',
    description: 'Cluster server untuk simulasi dan analisis data skala besar.',
    image: 'https://placehold.co/600x400.png',
    hint: 'server room',
  },
];

const staff = [
  { name: 'Dr. Iwan Setiawan', role: 'Kepala Laboratorium', avatar: 'IS' },
  { name: 'Rina Maryana, M.Si.', role: 'Analis Laboratorium', avatar: 'RM' },
  { name: 'Ahmad Faisal, S.T.', role: 'Teknisi Ahli', avatar: 'AF' },
];

export default function LabDetailsSection() {
  return (
    <section id="lab" className="w-full py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 md:px-6 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl font-headline">Detail Laboratorium</h2>
          <p className="mx-auto max-w-[700px] text-foreground/80 md:text-xl">
            Jelajahi fasilitas modern, kegiatan riset, dan tim ahli kami.
          </p>
        </div>

        <div>
          <h3 className="text-2xl font-bold mb-6 font-headline">Fasilitas Kami</h3>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {facilities.map((facility) => (
              <Card key={facility.name} className="overflow-hidden">
                <Image
                  src={facility.image}
                  alt={facility.name}
                  width={600}
                  height={400}
                  className="w-full h-48 object-cover"
                  data-ai-hint={facility.hint}
                />
                <CardHeader>
                  <CardTitle>{facility.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground/80">{facility.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="grid gap-10 md:grid-cols-2 items-start">
            <div>
                <h3 className="text-2xl font-bold mb-6 font-headline">Kegiatan Riset</h3>
                <ul className="space-y-4">
                    <li className="flex gap-4">
                        <Microscope className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold">Pengembangan Vaksin</h4>
                            <p className="text-foreground/80 text-sm">Riset aktif dalam pengembangan vaksin berbasis mRNA untuk penyakit tropis.</p>
                        </div>
                    </li>
                    <li className="flex gap-4">
                        <Beaker className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold">Sintesis Nanomaterial</h4>
                            <p className="text-foreground/80 text-sm">Membuat material baru pada skala nano untuk aplikasi elektronik dan medis.</p>
                        </div>
                    </li>
                     <li className="flex gap-4">
                        <Dna className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold">Analisis Genomik</h4>
                            <p className="text-foreground/80 text-sm">Studi genom untuk memahami penyakit genetik dan variasi populasi.</p>
                        </div>
                    </li>
                </ul>
            </div>
            <div>
                <h3 className="text-2xl font-bold mb-6 font-headline">Profil Staf</h3>
                <div className="space-y-4">
                {staff.map((s) => (
                    <Card key={s.name}>
                        <CardContent className="p-4 flex items-center gap-4">
                            <Avatar>
                                <AvatarFallback>{s.avatar}</AvatarFallback>
                            </Avatar>
                            <div>
                                <h4 className="font-semibold">{s.name}</h4>
                                <p className="text-sm text-foreground/80">{s.role}</p>
                            </div>
                        </CardContent>
                    </Card>
                ))}
                </div>
            </div>
        </div>

      </div>
    </section>
  );
}
